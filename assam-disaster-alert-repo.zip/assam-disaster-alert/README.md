# Assam Disaster Alert (Prototype)

> **Student prototype. Not an official warning system. Not affiliated with ASDMA, CWC, IMD or NDRF.**
> **In an emergency call 112.** Do not rely on this project for safety decisions.

A bilingual (English / Assamese) web dashboard for flood and earthquake awareness in Assam.
It combines live weather and earthquake data with an interactive map, a reference helpline directory,
and demo screens for river gauges and relief camps.

## What is real and what is demo

| Part | Status |
|------|--------|
| Weather and 24 h rainfall | **Live** from Open-Meteo. If the request fails the app says "unavailable" and shows no risk level. |
| Earthquakes (last 30 days, Assam region) | **Live** from USGS. If the request fails the app says "unavailable". |
| Hospitals, police, fire, shelters on the map | **Live** from OpenStreetMap (Overpass) when online, plus a few reference points (approximate locations). Shelters appear only if tagged in OSM. |
| River gauge levels | **Sample data. Not live CWC readings.** |
| Relief camps (names, capacity, occupancy) | **Sample data.** Not real camps. |
| District "vulnerability tier" and flood overlay polygons | **Sample / illustrative.** |
| "Simulate Flood" button | Synthetic 135 mm rainfall scenario with a visible SIMULATION banner. |
| SOS form | **Demo only.** Saves nothing and contacts nobody. It tells the user to call 112. |
| Helpline numbers | Only standard short codes are dialled: 112, 100, 101, 108, 1091, 1098, 1033, plus 1070 and 1077, which were cross-checked against public reports on 12 Nov 2026. All other landlines and mobiles were removed because they could not be verified. **Confirm numbers on official sites before relying on them.** |
| Photos | Generated placeholders. See `images/CREDITS.md`. |

## Features
- District selector (Assam districts), "My Location" via browser GPS
- Rainfall-based risk badge and rain progression chart
- Interactive Leaflet map: hospitals, police, fire stations, shelters, earthquakes, sample gauges
- Helplines popup and sample relief camp directory (click to call on phones)
- English / Assamese toggle
- Demo siren (Web Audio), simulation mode, mobile-friendly layout

## Tech stack
Vanilla HTML, CSS and JavaScript; [Leaflet](https://leafletjs.com/) for maps; a small Node.js static server for local development (no dependencies).

## Run locally
Requires Node.js 18 or newer and an internet connection (map tiles, fonts, icons and data come from public services).

```bash
git clone <your-repo-url>
cd assam-disaster-alert
node local_server.js
# open http://localhost:3000
```

You can also use `npm start`. The server only serves `index.html`, `style.css`, `script.js` and the `images/` folder.

## Project structure
```
index.html        page markup
style.css         styles
script.js         app logic, text for English/Assamese, sample data
local_server.js   tiny static dev server
images/           placeholder photos + CREDITS.md
```

## Data sources and attribution
- Weather: [Open-Meteo](https://open-meteo.com/) (CC BY 4.0)
- Earthquakes: [USGS Earthquake Hazards Program](https://earthquake.usgs.gov/)
- Places: [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors (ODbL) via the Overpass API
- Map tiles: OpenStreetMap / HOT, CARTO, Esri World Imagery, OpenTopoMap (attribution shown on the map)
- Libraries: Leaflet (BSD-2), Font Awesome Free, Google Fonts

## Known limitations
- No backend or database: nothing is stored and no alerts are sent.
- Sample river gauge and relief camp data must be replaced with an authoritative source before any real use.
- Helpline list is a short reference set, not a full directory.
- Assamese text was written for this prototype and should be reviewed by a native speaker.
- Tested in headless Chromium with mocked APIs; not tested on real phones or in all browsers.

## Roadmap (future work)
- Backend (Node/Express + database) to store SOS requests and serve helplines and camps from a maintained table
- Real CWC / ASDMA data integration if an official public feed becomes available
- Automated tests and a hosted demo

## Privacy
The app does not collect or send personal data to any server of its own. Your approximate location is used in the browser only if you press "My Location", and is sent to Open-Meteo and Overpass to fetch local data.

## License
No license has been chosen yet. Until one is added, all rights are reserved by the author. (Add a `LICENSE` file, for example MIT, if you want others to reuse the code.)

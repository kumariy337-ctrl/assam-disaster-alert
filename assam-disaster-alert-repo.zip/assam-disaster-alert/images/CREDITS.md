# Image credits

The five `.jpg` files in this folder are **generated placeholders** (a coloured gradient with a caption).
They are not photographs of real events. Replace each one with a photo you have the right to use,
keeping the same file name, and fill in the table below.

| File | Should show | Source URL | License | Photographer / credit |
|------|-------------|------------|---------|-----------------------|
| brahmaputra_flood_aerial.jpg | Aerial view of the Brahmaputra floodplain | | | |
| ndrf_boat_rescue.jpg | Boat evacuation of flooded homes | | | |
| assam_rescue_chopper.jpg | Helicopter relief drop | | | |
| flood_relief_camp.jpg | Relief camp / water distribution | | | |
| kaziranga_rescue.jpg | Wildlife / livestock relocation | | | |

Good sources: Wikimedia Commons (check each file's license), Unsplash/Pexels (check terms), or your own photos.
Do not use images copied from Google Images or news sites without permission.

// Minimal static file server for local development of the Assam Disaster Alert prototype.
// Usage: node local_server.js   (then open http://localhost:3000)
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
// Only these files/folders are served (keeps server code, package.json, etc. private).
const PUBLIC_FILES = new Set(['index.html', 'style.css', 'script.js']);
const PUBLIC_DIRS = ['images'];

const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp'
};

function send(res, code, body, type = 'text/plain; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff' });
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method Not Allowed');

  let reqPath;
  try {
    reqPath = decodeURIComponent(req.url.split('?')[0]);
  } catch (e) {
    return send(res, 400, 'Bad Request');
  }
  if (reqPath.includes('\0')) return send(res, 400, 'Bad Request');
  if (reqPath === '/') reqPath = '/index.html';

  const rel = path.normalize(reqPath).replace(/^[/\\]+/, '');
  const filePath = path.join(ROOT, rel);

  // Block anything that resolves outside the project folder.
  if (filePath !== ROOT && !filePath.startsWith(ROOT + path.sep)) return send(res, 403, 'Forbidden');

  const topLevel = rel.split(path.sep)[0];
  const allowed = PUBLIC_FILES.has(rel) || PUBLIC_DIRS.includes(topLevel);
  if (!allowed) return send(res, 404, '404 Not Found');

  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) return send(res, 404, '404 Not Found');
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': mimeTypes[ext] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff'
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
});

server.listen(PORT, () => {
  console.log(`Static server listening on http://localhost:${PORT}`);
});
